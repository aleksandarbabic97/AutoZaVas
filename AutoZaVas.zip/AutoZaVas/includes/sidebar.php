<div class="profile_nav">
          <ul>
          <li><a href="profile.php">Profil Podesavanja</a></li>
              <li><a href="update-password.php">Azurirajte lozinku</a></li>
            <li><a href="my-booking.php">Moj buking</a></li>
            <li><a href="post-testimonial.php">Postavite potvrdu</a></li>
          <li><a href="my-testimonials.php">Moje potvrde</a></li>
            <li><a href="logout.php">Izloguj se</a></li>
          </ul>
        </div>
</div>